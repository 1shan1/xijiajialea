#include "data_augment.hpp"
#include "config.hpp"
#include <glog/logging.h>

namespace mx {
    data_augment::data_augment()
            : rand_gen_(std::random_device()()) {

    }

   int data_augment::process(const cv::Mat &in_img,std::vector<int>&randm_vect,std::vector<cv::Mat > &dest_out_vect) {
        float prob;
        prob = randfloat(0, 1);
        cv::Mat out_img = in_img.clone();

//        out_img = random_size(out_img, 60, 60);
       /* if (prob < config::ins().augment_prob()) {
            out_img = random_brightness(out_img);
            out_img = random_contrast(out_img);
            out_img = random_saturation(out_img);
            out_img = random_hue(out_img);
            out_img = random_order_channels(out_img);
            out_img = smooth(out_img);
            out_img = random_noise(out_img);
            //out_img = random_motion_blur(out_img);
            //out_img = warp_affine(out_img);
            //out_img = horizontal_flip(out_img);
            out_img = img_to_gray(out_img);
        }*/
       ///////////////////////////////////////////////////////

        random_shuffle(randm_vect.begin(),randm_vect.end());
        for (int dw = 0; dw <3 ; ++dw)
        {
            cv::Mat tmpout;
            int randm_num=randm_vect[dw];
            switch (randm_num)
            {
                case 0:
                    tmpout = random_brightness(out_img);
                    break;
                case 1:
                    tmpout = random_contrast(out_img);
                    break;
                case 2:
                    tmpout = random_saturation(out_img);
                    break;
                case 3:
                    tmpout = random_hue(out_img);
                    break;
                case 4:
                    tmpout = random_order_channels(out_img);
                    break;
                case 5:
                    tmpout = smooth(out_img);
                    break;
                case 6:
                    tmpout = random_noise(out_img);
                    break;
                case 7:
                    tmpout = img_to_gray(out_img);
                    break;
                default:
                    std::cout<<std::endl<<"******* data augment *******"<<std::endl;
            }

            dest_out_vect.push_back(tmpout);
        }

        return 0;
    }

    cv::Mat data_augment::horizontal_flip(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob = randfloat(0, 1);

        if (prob < config::ins().flip_prob()) {
            cv::flip(in_img, out_img, 1); // 1: y axis; 0: x axis
        } else {
            out_img = in_img.clone();
        }

        return out_img;
    }

    cv::Mat data_augment::warp_affine(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);

        if (prob < config::ins().warp_affine_prob()) {
            CHECK_GE(config::ins().warp_affine_angle_uppper(), config::ins().warp_affine_angle_lower())
                << "warp_affine upper must be >= lower.";

            float delta;
            delta = randfloat(config::ins().warp_affine_angle_lower(), config::ins().warp_affine_angle_uppper());

            cv::Point2f center(in_img.cols / 2, in_img.rows / 2);
            cv::Mat M = cv::getRotationMatrix2D(center, delta, 1);

            cv::warpAffine(in_img, out_img, M, cv::Size(in_img.cols, in_img.rows));
        } else {
            out_img = in_img.clone();
        }

        return out_img;
    }

    cv::Mat data_augment::img_to_gray(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);
        if (prob < config::ins().gray_prob()) {
            cv::cvtColor(in_img, out_img, CV_BGR2GRAY);
        } else {
            out_img = in_img.clone();
        }

        return out_img;
    }

    cv::Mat data_augment::random_size(const cv::Mat &in_img, int width, int height) {
        cv::Mat out_img;

        cv::resize(in_img, out_img, cv::Size(width, height));
        return out_img;
    }

    cv::Mat data_augment::random_brightness(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);
        if (prob < config::ins().bright_prob()) {
            CHECK_GE(config::ins().bright_upper(), config::ins().saturation_lower())
                << "bright upper must be >= lower.";

            float delta;
            delta = randfloat(config::ins().bright_lower(), config::ins().bright_upper());
            out_img = AdjustBrightness(in_img, delta);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::random_contrast(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);
        if (prob < config::ins().contrast_prob()) {
            CHECK_GE(config::ins().contrast_upper(), config::ins().contrast_lower())
                << "contrast upper must be >= lower.";
            CHECK_GE(config::ins().contrast_lower(), 0) << "contrast lower must be non-negative.";
            float delta;
            delta = randfloat(config::ins().contrast_lower(), config::ins().contrast_upper());
            out_img = AdjustContrast(in_img, delta);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::random_saturation(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);
        if (prob < config::ins().saturation_prob()) {
            CHECK_GE(config::ins().saturation_upper(), config::ins().saturation_lower())
                << "saturation upper must be >= lower.";
            CHECK_GE(config::ins().saturation_lower(), 0) << "saturation lower must be non-negative.";
            float delta;
            delta = randfloat(config::ins().saturation_lower(), config::ins().saturation_upper());
            out_img = AdjustSaturation(in_img, delta);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::random_hue(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0, 1);
        if (prob < config::ins().hue_prob()) {
            CHECK_GE(config::ins().hue_upper(), config::ins().saturation_lower()) << "hue upper must be >= lower.";

            float delta;
            delta = randfloat(config::ins().hue_lower(), config::ins().hue_upper());
            out_img = AdjustHue(in_img, delta);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::random_order_channels(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0.f, 1.f);
        if (prob < config::ins().random_order_prob()) {
            // Split the image to 3 channels.
            std::vector<cv::Mat> channels;
            cv::split(in_img, channels);
            CHECK_EQ(channels.size(), 3);

            // Shuffle the channels.
            std::random_shuffle(channels.begin(), channels.end());
            cv::merge(channels, out_img);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::smooth(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0.f, 1.f);
        if (prob < config::ins().smooth_prob()) {
            switch (config::ins().smooth_type()) {
                case 0:
                    //cv::Smooth(cv_img, cv_img, smooth_type, smooth_param1);
                    cv::GaussianBlur(in_img, out_img,
                                     cv::Size(config::ins().smooth_param(), config::ins().smooth_param()), 0);
                    break;
                case 1:
                    cv::blur(in_img, out_img, cv::Size(config::ins().smooth_param(), config::ins().smooth_param()));
                    break;
                case 2:
                    cv::medianBlur(in_img, out_img, config::ins().smooth_param());
                    break;
                case 3:
                    cv::boxFilter(in_img, out_img, -1,
                                  cv::Size(config::ins().smooth_param() * 2, config::ins().smooth_param() * 2));
                    break;
            }
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::random_noise(const cv::Mat &in_img) {
        cv::Mat out_img = in_img.clone();
        float prob;
        prob = randfloat(0.f, 1.f);
        if (prob < config::ins().random_noise_prob()) {
            unsigned char *data = static_cast<unsigned char *>(out_img.data);
            int datalen = out_img.rows * out_img.cols * out_img.channels();
            for (int i = 0; i < datalen; i++) {
                data[i] = randint(0, 255);
            }

            cv::GaussianBlur(out_img, out_img,
                             cv::Size(config::ins().random_noise_beta(), config::ins().random_noise_beta()),
                             0);

            out_img = out_img * config::ins().random_noise_delta() + in_img;
        }

        return out_img;
    }

    cv::Mat data_augment::random_motion_blur(const cv::Mat &in_img) {
        cv::Mat out_img;
        float prob;
        prob = randfloat(0.f, 1.f);
        if (prob < config::ins().motion_blur_prob()) {
            int len = config::ins().motion_blur_len();
            int delta = config::ins().motion_blur_len_delta();
            CHECK(len - delta > 0) << "len - delta smaller than 0 in random_motion_blur";
            int kernellen = randint(len - delta, len + delta);
            float angle = randint(0, 180);
            cv::Mat kernel = genarate_motion_kernel(kernellen, angle);
            cv::filter2D(in_img, out_img, 0, kernel);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }


    int data_augment::randint(const int a, const int b) {
        std::uniform_int_distribution<> rand_int(a, b);
        return rand_int(rand_gen_);
    }

    float data_augment::randfloat(const float a, const float b) {
        std::uniform_real_distribution<> randfloat(a, b);
        return randfloat(rand_gen_);
    }

    cv::Mat data_augment::AdjustBrightness(const cv::Mat &in_img, const float delta) {
        cv::Mat out_img;
        if (fabs(delta) > 0) {
            in_img.convertTo(out_img, -1, 1, delta);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::AdjustHue(const cv::Mat &in_img, const float delta) {
        cv::Mat out_img;
        if (fabs(delta) > 0) {
            cv::cvtColor(in_img, out_img, CV_BGR2HSV);
            std::vector<cv::Mat> channels;
            cv::split(out_img, channels);
            channels[0].convertTo(channels[0], -1, 1, delta);
            cv::merge(channels, out_img);
            cvtColor(out_img, out_img, CV_HSV2BGR);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::AdjustSaturation(const cv::Mat &in_img, const float delta) {
        cv::Mat out_img;
        if (fabs(delta - 1.f) != 1e-3) {
            cv::cvtColor(in_img, out_img, CV_BGR2HSV);
            std::vector<cv::Mat> channels;
            cv::split(out_img, channels);
            channels[1].convertTo(channels[1], -1, delta, 0);
            cv::merge(channels, out_img);
            cvtColor(out_img, out_img, CV_HSV2BGR);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

    cv::Mat data_augment::AdjustContrast(const cv::Mat &in_img, const float delta) {
        cv::Mat out_img;
        if (fabs(delta - 1.f) > 1e-3) {
            in_img.convertTo(out_img, -1, delta, 0);
        } else {
            out_img = in_img.clone();
        }
        return out_img;
    }

/*
cv::Mat data_augment::genarate_motion_kernel(const double len, const double angle)
{
    cv::Mat psf;
    double half=len/2;											
    double alpha = (angle-floor(angle/ 180) *180) /180* CV_PI;
    double cosalpha = cos(alpha);
    double sinalpha = sin(alpha);
    int xsign;
    if (cosalpha < 0)
    {
	    xsign = -1;
    }
    else
    {
	    if (angle == 90)
	    {
		    xsign = 0;
	    }
	    else
	    {
		    xsign = 1;
	    }
    }
    int psfwdt = 1;
    int sx = (int)fabs(half*cosalpha + psfwdt*xsign - len*1e-6);
    int sy = (int)fabs(half*sinalpha + psfwdt - len*1e-6);
    cv::Mat_<double> psf1(sy, sx, CV_64F);
    cv::Mat_<double> psf2(sy * 2, sx * 2, CV_64F);
    int row = 2 * sy;
    int col = 2 * sx;

    for (int i = 0; i < sy; i++)
    {
	    double* pvalue = psf1.ptr<double>(i);
	    for (int j = 0; j < sx; j++)
	    {
		    pvalue[j] = i*fabs(cosalpha) - j*sinalpha;

		    double rad = sqrt(i*i + j*j);
		    if (rad >= half && fabs(pvalue[j]) <= psfwdt)
		    {
			    double temp = half - fabs((j + pvalue[j] * sinalpha) / cosalpha);
			    pvalue[j] = sqrt(pvalue[j] * pvalue[j] + temp*temp);
		    }
		    pvalue[j] = psfwdt + 1e-6 - fabs(pvalue[j]);
		    if (pvalue[j] < 0)
		    {
			    pvalue[j] = 0;
		    }
	    }
    }

    for (int i = 0; i < sy; i++)
    {
	    double* pvalue1 = psf1.ptr<double>(i);
	    double* pvalue2 = psf2.ptr<double>(i);
	    for (int j = 0; j < sx; j++)
	    {
		    pvalue2[j] = pvalue1[j];
	    }
    }

    for (int i = 0; i < sy; i++)
    {
	    for (int j = 0; j < sx; j++)
	    {
		    psf2[2 * sy -1 - i][2 * sx -1 - j] = psf1[i][j];
		    psf2[sy + i][j] = 0;
		    psf2[i][sx + j] = 0;
	    }
    }

    double sum = 0;
    for (int i = 0; i < row; i++)
    {
	    for (int j = 0; j < col; j++)
	    {
		    sum+= psf2[i][j];
	    }
    }
    psf2 = psf2 / sum;
    if (cosalpha>0)
    {
	    cv::flip(psf2, psf2, 0);
    }

    psf = psf2;
    return psf;
}
*/
    cv::Mat data_augment::genarate_motion_kernel(const int len, const int angle) {
        double eps = 1e-6;
        double clen = std::max(1, len);
        double half = (clen - 1) / 2;
        double phi = (double) (angle % 180) / 180 * CV_PI;

        double cosphi = cos(phi);
        double sinphi = sin(phi);
        int xsign = cosphi >= 0 ? 1 : -1;
        int linewdt = 1;

        int sx = int(half * cosphi + linewdt * xsign - clen * eps);
        int sy = int(half * sinphi + linewdt - clen * eps);

        int width = abs(sx) + 1;
        int height = abs(sy) + 1;
        int realwidth = width * 2 - 1;
        int realheight = height * 2 - 1;

        cv::Mat kernel(realheight, realwidth, CV_64FC1, cv::Scalar(0.));
        //cv::Mat rad(height, width, CV_64FC1);
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                int xi = j * xsign;
                int yi = i;

                double &kerneli = kernel.at<double>(i, j);
                kerneli = yi * cosphi - xi * sinphi;
                //rad.at<double>(i, j)=std::sqrt(xi*xi+yi*yi);
                double rad = std::sqrt(xi * xi + yi * yi);

                if (rad >= half && abs(kerneli <= linewdt)) {
                    double x2lastpix = half - abs((xi + kerneli * sinphi) / cosphi);
                    kerneli = std::sqrt(kerneli * kerneli + x2lastpix * x2lastpix);
                }
                kerneli = linewdt + eps - abs(kerneli);
                kerneli = kerneli > 0 ? kerneli : 0;
            }
        }
        for (int i = realheight - 1; i >= height - 1; i--) {
            for (int j = realwidth - 1; j >= width - 1; j--) {
                kernel.at<double>(i, j) = kernel.at<double>(realheight - 1 - i, realwidth - 1 - j);
            }
        }

        if (cosphi > 0) {
            cv::Mat kernel_temp = kernel.clone();
            for (int i = 0; i < realheight; i++) {
                for (int j = 0; j < realwidth; j++) {
                    kernel.at<double>(i, j) = kernel_temp.at<double>(realheight - 1 - i, j);
                }
            }
        }

        double *kernel_data = reinterpret_cast<double *>(kernel.data);
        double kernel_sum = 0.;
        for (int i = 0; i < realheight * realwidth; i++) {
            kernel_sum += kernel_data[i];
        }
        for (int i = 0; i < realheight * realwidth; i++) {
            kernel_data[i] /= kernel_sum;
        }
        return kernel;
    }
}

