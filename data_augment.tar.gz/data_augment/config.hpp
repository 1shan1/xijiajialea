#ifndef TUZHEN_ALG_CONFIG_HPP
#define TUZHEN_ALG_CONFIG_HPP

#include <opencv2/opencv.hpp>
#include "config.prototxt.pb.h"

namespace mx {
    class config {
    public:
        static config &ins();

        float augment_prob();

        float bright_prob();

        float bright_lower();

        float bright_upper();

        float contrast_prob();

        float contrast_lower();

        float contrast_upper();

        float saturation_prob();

        float saturation_lower();

        float saturation_upper();

        float hue_prob();

        float hue_lower();

        float hue_upper();

        float random_order_prob();

        float smooth_prob();

        int smooth_type();

        int smooth_param();

        float random_noise_prob();

        float random_noise_delta();

        float random_noise_beta();

        float motion_blur_prob();

        int motion_blur_len();

        int motion_blur_len_delta();

        float warp_affine_prob();

        int warp_affine_angle_lower();

        int warp_affine_angle_uppper();

        float flip_prob();

        float gray_prob();

    protected:
        config();

    private:
        config_internal config_;
    };
}

#endif

