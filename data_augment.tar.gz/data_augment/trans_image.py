import os
import cv2
import random
import numpy as np
import shutil

def get_save_img():
    rec_root = '/media/d/jiakao_data/20170822_pick_3/'
    src_root = '/media/e/jiakao/imgs/result_img_0822/'
    dst_root = '/media/f/jiakao/imgs/save_imgs/save_img_0826/'
    folder_names = os.listdir(rec_root)
    for folder_name in folder_names:
        print 'folder: ',folder_name
        folder_path = rec_root + folder_name + '/'
        label_names = os.listdir(folder_path)
        for label_name in label_names:
            print 'label: ',label_name
            label_path = folder_path + label_name + '/'
            pic_names = os.listdir(label_path)
            for pic_name in pic_names:
                src_img_name = pic_name.replace('_rec','')
                src_img_path = src_root + folder_name + '/' + src_img_name
                src_text_path = src_img_path[0:-3] + 'txt'
                if(not (os.path.isfile(src_text_path))):
                    continue
                with open(src_text_path,'r') as f:
                    txt_words = f.readline()
                rect_word = txt_words.split()
                rec_x = int(rect_word[0])
                rec_y = int(rect_word[1])
                rec_w = int(rect_word[2])
                rec_h  =int(rect_word[3])
                srcim = cv2.imread(src_img_path)
                h,w,c = srcim.shape
                recim = srcim[rec_y:(rec_y + rec_h), rec_x:(rec_x + rec_w)]
                save_path = dst_root +label_name+'/'+src_img_name
                cv2.imwrite(save_path,recim)
                #get extern imgs
                for k in range(5):
                    xx=random.randint(-10, 10)
                    yy=random.randint(-10, 10)
                    scale=random.uniform(0.9, 1.1)
                    coor1=[0,0,0,0]
                    coor1[0]=int(rec_x+xx)
                    coor1[1]=int(rec_y+yy)
                    coor1[2]=int(rec_w*scale)
                    coor1[3]=int(rec_h*scale)
                    index = src_img_name.rfind('.')
                    k_img_name = src_img_name[:index]+'_'+str(k)+'.jpg'
                    img1=srcim[coor1[1]:coor1[1]+coor1[3]-1, coor1[0]:coor1[0]+coor1[2]-1, :]
                    cv2.imwrite(dst_root +label_name+'/'+k_img_name, img1)

if __name__ == '__main__':
    get_save_img()