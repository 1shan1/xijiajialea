#include <iostream>
#include <glog/logging.h>
#include <opencv2/opencv.hpp>
#include <random>
#include <fstream>
#include "data_augment.hpp"


#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>

static inline void rtrim(std::string &s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
        return !std::isspace(ch);
    }).base(), s.end());
}

/*int main0() {
    cv::Mat img = cv::imread(
            "/media/f/jiakao/imgs/train_imgs/train_img_0902/kan-dang/20170826__946684870_112_6_dw21.43_ybp10.33_ya8.46.jpg");
    cv::imshow("mx", img);
    cv::waitKey(0);

    mx::data_augment aug;
    while (true) {
        cv::Mat img1 = img.clone();
        img1 = aug.process(img1);
        cv::Mat m = img1.t();
        cv::imshow("mx", m);
        cv::waitKey(0);
    }

    return 0;
}
*/
int mkdir(boost::filesystem::path fullsavefolderpath)
{
    using namespace boost::filesystem;
    if(!exists(fullsavefolderpath))
        create_directories(fullsavefolderpath);
    return 0;
}
int loadrandom(std::vector<int>& randm_vect)
{
    randm_vect.clear();
    for (int dwi = 0; dwi <8 ; ++dwi)
    {
        randm_vect.push_back(dwi);
    }
    return 0;
}
int main() {
    std::string srcimglist="/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/data/formatted_trainval/shanghaitech_part_A_patches_100/val_img.txt";
    std::string savefolderpath="/media/pengshanzhen/bb42233c-19d1-4423-b161-e5256766be8e/data/formatted_trainval/shanghaitech_part_A_patches_100/training-augment/val";

    boost::filesystem::path tmpfolder(savefolderpath);
    std::string foldername=tmpfolder.filename().string();
    std::string saveimglist=savefolderpath+"/"+foldername+"_augmentlist.txt";
    std::ofstream wrtfile(saveimglist,std::ios::app);

    std::vector<int>randm_vect;
    loadrandom(randm_vect); //加载随机向量


    std::ifstream fid(srcimglist);
    std::string line;
    mx::data_augment aug;
    int save_num = 0;
    while (std::getline(fid, line))
    {
        if(!line.empty())
        {
        /*rtrim(line);
        int space_index = line.find(" /");
        std::string src = line.substr(0, space_index);*/
        //std::string dst = line.substr(space_index + 1);
         std::string src=line;
        ///save image path process
        boost::filesystem::path pathtmp(src);
        std::string rmextfilename=pathtmp.stem().string();
        std::string parentfolder=pathtmp.parent_path().filename().string();
        boost::filesystem::path fullsavefolderpath=savefolderpath+"/"+parentfolder+"_augment";
        mkdir(fullsavefolderpath);


        std::vector<cv::Mat > dest_out_vect;  //存放增广后的图片向量
        dest_out_vect.clear();
        /// data augment
        cv::Mat img = cv::imread(src);
       // imshow("test",img);
       // cvWaitKey(0);
        aug.process(img,randm_vect,dest_out_vect);

        for (int dwj = 0; dwj < dest_out_vect.size(); ++dwj)
        {
            std::string dst =fullsavefolderpath.string()+"/"+rmextfilename+"X_agmt"+"_"+std::to_string(dwj)+pathtmp.extension().string();
            cv::imwrite(dst, dest_out_vect[dwj]);
            save_num++;
            if (save_num % 10000 == 0 && save_num > 0) {
                std::cout << "save_num: " << save_num << std::endl;
            }
            wrtfile << dst << std::endl;
        }



        }
    }
    wrtfile.close();

    return 0;
}
