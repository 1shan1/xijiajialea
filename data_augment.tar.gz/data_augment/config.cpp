#include <google/protobuf/text_format.h>
#include <google/protobuf/io/zero_copy_stream_impl.h>
#include <fcntl.h>
#include <glog/logging.h>
#include "config.hpp"

namespace mx {
    config::config() {
        int fid = open("./../config.ini", O_RDONLY);
        CHECK_GE(fid, 0) << "can't open config file";
        google::protobuf::io::FileInputStream fileInput(fid);
        fileInput.SetCloseOnDelete(true);
        bool success = google::protobuf::TextFormat::Parse(&fileInput, &config_);
        CHECK(success) << "can't parse the config file";
    }

    config &config::ins() {
        static config obj;
        return obj;
    }

    float config::augment_prob() {
        return config_.augment_prob();
    }


    float config::bright_prob() {
        return config_.bright_prob();
    }

    float config::bright_lower() {
        return config_.bright_lower();
    }

    float config::bright_upper() {
        return config_.bright_upper();
    }

    float config::contrast_prob() {
        return config_.contrast_prob();
    }

    float config::contrast_lower() {
        return config_.contrast_lower();
    }

    float config::contrast_upper() {
        return config_.contrast_upper();
    }


    float config::saturation_prob() {
        return config_.saturation_prob();
    }

    float config::saturation_lower() {
        return config_.saturation_lower();
    }

    float config::saturation_upper() {
        return config_.saturation_upper();
    }


    float config::hue_prob() {
        return config_.hue_prob();
    }

    float config::hue_lower() {
        return config_.hue_lower();
    }

    float config::hue_upper() {
        return config_.hue_upper();
    }


    float config::random_order_prob() {
        return config_.random_order_prob();
    }

    float config::smooth_prob() {
        return config_.smooth_prob();
    }

    int config::smooth_type() {
        return config_.smooth_type();
    }

    int config::smooth_param() {
        return config_.smooth_param();
    }


    float config::random_noise_prob() {
        return config_.random_noise_prob();
    }

    float config::random_noise_delta() {
        return config_.random_noise_delta();
    }

    float config::random_noise_beta() {
        return config_.random_noise_beta();
    }


    float config::motion_blur_prob() {
        return config_.motion_blur_prob();
    }

    int config::motion_blur_len() {
        return config_.motion_blur_len();
    }

    int config::motion_blur_len_delta() {
        return config_.motion_blur_len_delta();
    }

    float config::warp_affine_prob() {
        return config_.warp_affine_prob();
    }

    int config::warp_affine_angle_lower() {
        return config_.warp_affine_angle_lower();
    }

    int config::warp_affine_angle_uppper() {
        return config_.warp_affine_angle_upper();
    }

    float config::flip_prob() {
        return config_.flip_prob();
    }

    float config::gray_prob() {
        return config_.gray_prob();
    }
}









