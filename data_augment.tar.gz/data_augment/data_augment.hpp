#ifndef MX_DATA_AUGMENT_HPP
#define MX_DATA_AUGMENT_HPP

#include <opencv2/opencv.hpp>
#include <random>

namespace mx {
    class data_augment {
    public:
        data_augment();

        int process(const cv::Mat &in_img,std::vector<int>&randm_vect,std::vector<cv::Mat > &dest_out_vect);

    private:
        cv::Mat random_brightness(const cv::Mat &in_img);

        cv::Mat random_contrast(const cv::Mat &in_img);

        cv::Mat random_saturation(const cv::Mat &in_img);

        cv::Mat random_hue(const cv::Mat &in_img);

        cv::Mat random_order_channels(const cv::Mat &in_img);

        cv::Mat smooth(const cv::Mat &in_img);

        cv::Mat random_noise(const cv::Mat &in_img);

        cv::Mat random_motion_blur(const cv::Mat &in_img);

        cv::Mat random_size(const cv::Mat &in_img, int width, int height);

        int randint(const int a, const int b);

        float randfloat(const float a, const float b);

        cv::Mat img_to_gray(const cv::Mat &in_img);

        cv::Mat horizontal_flip(const cv::Mat &in_img);

        cv::Mat warp_affine(const cv::Mat &in_img);

        cv::Mat AdjustBrightness(const cv::Mat &in_img, const float delta);

        cv::Mat AdjustHue(const cv::Mat &in_img, const float delta);

        cv::Mat AdjustSaturation(const cv::Mat &in_img, const float delta);

        cv::Mat AdjustContrast(const cv::Mat &in_img, const float delta);

        cv::Mat genarate_motion_kernel(const int len, const int angle);

    private:
        std::mt19937 rand_gen_;

    };

}

#endif

